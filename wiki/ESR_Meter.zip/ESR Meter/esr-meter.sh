#!/bin/sh

"pvengine.exe" +W320 +H240 +FN +L"c:/windows/fonts" +L"/Applications/EAGLE/eagle3d/ulp//../povray" +O"/Users/dm/Documents/eagle/ESR Meter/esr-meter.png" /Users/dm/Documents/eagle/ESR Meter/esr-meter.pov 
