#include "C:\Documents and Settings\Administrator\My Documents\pic-c\qrss beacon\2mmain.h"
BYTE CONST LED_MAP[10] = {0x90,0xb7,0x19,0x15,0x36,0x54,0x50,0xb5,0,0x24};

void display_segs(char c) {
  if((c>'9')||(C<'0'))
    output_b(0xff);
  else
    output_b(~LED_MAP[c-'0']);
}

void dit(int dot_length, int16 mult)
{
output_high(key);
delay_ms(dot_length * mult);
output_low(key);
delay_ms(dot_length * mult);
}

void dah(int dot_length, int16 mult)
{
output_high(key);
delay_ms(3 * dot_length * mult);
output_low(key);
delay_ms(dot_length * mult);
}

void audio_ID(void)
{
//G7UVW VHF QRSS MEPT
//--. --... ..- ...- .--   ...- .... ..-.   --.- .-. ... ...   -- . .--. - 
int dot12 = 100;
   //G
dah(dot12,1);
dah(dot12,1);
dit(dot12,1);

delay_ms(3 * dot12 );

   //7
dah(dot12,1);
dah(dot12,1);
dit(dot12,1);
dit(dot12,1);
dit(dot12,1);

delay_ms(3 * dot12);

   //U
dit(dot12,1);
dit(dot12,1);
dah(dot12,1);

delay_ms(3 * dot12);

   //V
dit(dot12,1);
dit(dot12,1);
dit(dot12,1);
dah(dot12,1);

delay_ms(3 * dot12);

   //W
dit(dot12,1);
dah(dot12,1);
dah(dot12,1);

delay_ms(10 * dot12);
 //V
dit(dot12,1);
dit(dot12,1);
dit(dot12,1);
dah(dot12,1);
//H
delay_ms(3 * dot12);
dit(dot12,1);
dit(dot12,1);
dit(dot12,1);
dit(dot12,1);
delay_ms(3 * dot12);

//F
dit(dot12,1);
dit(dot12,1);
dah(dot12,1);
dit(dot12,1);
delay_ms(10 * dot12);

//Q
dah(dot12,1);
dah(dot12,1);
dit(dot12,1);
dah(dot12,1);
delay_ms(3 * dot12);
//R
dit(dot12,1);
dah(dot12,1);
dit(dot12,1);
//S
delay_ms(3 * dot12);
dit(dot12,1);
dit(dot12,1);
dit(dot12,1);
//S
delay_ms(3 * dot12);
dit(dot12,1);
dit(dot12,1);
dit(dot12,1);

delay_ms(10 * dot12);
//M
dah(dot12,1);
dah(dot12,1);
delay_ms(3 * dot12);
//E
dit(dot12,1);
delay_ms(3 * dot12);
//P
dit(dot12,1);
dah(dot12,1);
dah(dot12,1);
dit(dot12,1);
delay_ms(3 * dot12);
//T
dah(dot12,1);

}
void qrss_x(int dot_length)
{
   // sends G7UVW, A1A Morse
   // dot length sent is dot_length in s
   // dot_length = 3 gives 3sec dots.
   
   //  --. --... ..- ...- .--  = G 7 U V W
   
   //G
dah(dot_length,1000);
dah(dot_length,1000);
dit(dot_length,1000);

delay_ms(3 * dot_length * 1000);

   //7
dah(dot_length,1000);
dah(dot_length,1000);
dit(dot_length,1000);
dit(dot_length,1000);
dit(dot_length,1000);

delay_ms(3 * dot_length * 1000);

   //U
dit(dot_length,1000);
dit(dot_length,1000);
dah(dot_length,1000);

delay_ms(3 * dot_length * 1000);

   //V
dit(dot_length,1000);
dit(dot_length,1000);
dit(dot_length,1000);
dah(dot_length,1000);

delay_ms(3 * dot_length * 1000);

   //W
dit(dot_length,1000);
dah(dot_length,1000);
dah(dot_length,1000);
}



void main()
{

   setup_timer_0(RTCC_INTERNAL|RTCC_DIV_1);
   setup_timer_1(T1_DISABLED);
   setup_timer_2(T2_DISABLED,0,1);
   setup_comparator(NC_NC_NC_NC);
   setup_vref(FALSE);
   
   output_low(key);      //turn off transmitter
   //give xtal a chance to warm up
   delay_ms(5000);
   delay_ms(5000);
   
  
                           
   while(1)
   {
   display_segs("0");
   audio_ID();
   display_segs("3");
   qrss_x(3);
   output_low(key);
   delay_ms(20000);
   display_segs("6");
   qrss_x(6);
   output_low(key);
   delay_ms(20000);
   display_segs("1");
   qrss_x(10);
   output_low(key);
   delay_ms(20000);
   }
  

}
